package com.example.jarvis

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast

/**
 * Runs in the background:
 *  - listens for the word "Jarvis" (Picovoice Porcupine, on-device)
 *  - shows a floating mic bubble as a backup (tap it from any app)
 */
class JarvisService : Service() {

    companion object { @Volatile var instance: JarvisService? = null }

    private var wm: WindowManager? = null
    private var bubble: View? = null
    private var porcupine: PorcupineManager? = null
    private var wl: PowerManager.WakeLock? = null
    private val main = Handler(Looper.getMainLooper())
    private val resumeTask = Runnable { startWake() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        instance = this
        val ch = "jarvis"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(ch, "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, ch)
            .setContentTitle("Jarvis sun raha hai")
            .setContentText("\"Jarvis\" bolke kaam batayein")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi).setOngoing(true).build()
        when {
            Build.VERSION.SDK_INT >= 34 -> startForeground(
                1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            Build.VERSION.SDK_INT >= 30 -> startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else -> startForeground(1, n)
        }
        if (Settings.canDrawOverlays(this)) addBubble()
        if (wl == null) wl = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:wake").apply { acquire() }
        startWake()
        return START_NOT_STICKY
    }

    private fun toast(t: String) = main.post { Toast.makeText(applicationContext, t, Toast.LENGTH_LONG).show() }

    private fun startWake() {
        val key = getSharedPreferences("jarvis", MODE_PRIVATE).getString("pkey", "") ?: ""
        if (key.isBlank()) { toast("Picovoice key nahi hai, sirf bubble chalega."); return }
        try {
            if (porcupine == null) {
                porcupine = PorcupineManager.Builder()
                    .setAccessKey(key)
                    .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                    .setSensitivity(0.7f)
                    .build(applicationContext, PorcupineManagerCallback { onWake() })
            }
            porcupine?.start()
        } catch (e: Exception) {
            toast("Wake word error: ${e.message}")
        }
    }

    private fun onWake() {
        main.post {
            try { porcupine?.stop() } catch (_: Exception) {}
            try { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150) } catch (_: Exception) {}
            try {
                startActivity(
                    Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        .putExtra("auto", true)
                )
            } catch (e: Exception) { toast("Jarvis khul nahi paaya: ${e.message}") }
            main.removeCallbacks(resumeTask)
            main.postDelayed(resumeTask, 25000)   // safety: start listening again
        }
    }

    /** Called by MainActivity when it has finished a voice command. */
    fun resumeListening() {
        main.removeCallbacks(resumeTask)
        main.postDelayed(resumeTask, 800)
    }

    private fun addBubble() {
        if (bubble != null) return
        val d = resources.displayMetrics.density
        val size = (56 * d).toInt()
        val v = TextView(this).apply {
            text = "🎤"; textSize = 22f; gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#E604101A"))
                setStroke((2 * d).toInt(), Color.parseColor("#5FE3FF"))
            }
        }
        val p = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = (200 * d).toInt() }

        var sx = 0f; var sy = 0f; var px = 0; var py = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; px = p.x; py = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (Math.abs(dx) > 12 || Math.abs(dy) > 12) moved = true
                    if (moved) { p.x = px + dx; p.y = py + dy; wm?.updateViewLayout(v, p) }
                }
                MotionEvent.ACTION_UP -> if (!moved) onWake()
            }
            true
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm?.addView(v, p)
        bubble = v
    }

    override fun onDestroy() {
        main.removeCallbacks(resumeTask)
        try { porcupine?.stop(); porcupine?.delete() } catch (_: Exception) {}
        porcupine = null
        bubble?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        bubble = null
        try { wl?.release() } catch (_: Exception) {}
        wl = null
        instance = null
        super.onDestroy()
    }
}
