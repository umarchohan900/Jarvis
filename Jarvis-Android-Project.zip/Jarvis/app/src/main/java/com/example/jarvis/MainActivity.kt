package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Build
import android.app.KeyguardManager
import android.telecom.TelecomManager
import android.view.WindowManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.app.SearchManager
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.*
import android.app.AlertDialog
import android.content.Context
import android.media.AudioManager
import android.os.BatteryManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private var auto = false
    private var pendingType: String? = null
    private var pendingAfterUnlock: String? = null
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var mic: Button
    private lateinit var input: EditText
    private val history = JSONArray()
    private val sys = "You are Jarvis, a voice assistant on the user's Android phone. " +
        "Reply in the same language and style as the user (Hinglish stays Hinglish in Roman letters). " +
        "Keep answers short: 1-3 sentences, no markdown. " +
        "If the user wants a phone action done, reply with exactly one line starting with CMD: followed by an English command " +
        "from this list: 'open <app>', 'call <name or number>', 'alarm <h:mm am/pm>', '<n> minute timer', 'torch on', 'torch off', " +
        "'play <query> youtube', 'navigate to <place>', 'search <query>', 'whatsapp <message text>', " +
        "'sms <name or number> <message>', 'email <body>', 'volume up', 'volume down', 'wifi', 'bluetooth', 'battery'. " +
        "If the user asks you to type or write some text (a message, reply, note, caption), reply with exactly one line: TYPE: followed by the text, " +
        "written in Urdu using English letters (Roman Urdu, e.g. \"Assalamualaikum, main theek hoon, aap kaise hain?\"), unless they ask for another language. " +
        "Text inside CMD: whatsapp / sms / email commands must also be in Roman Urdu. " +
        "Otherwise just answer the question."

    // Hindi (Devanagari) names -> app names as they appear on the phone
    private val aliases = mapOf(
        "यूट्यूब" to "youtube", "व्हाट्सएप" to "whatsapp", "वॉट्सऐप" to "whatsapp",
        "कैमरा" to "camera", "गैलरी" to "gallery", "सेटिंग" to "settings",
        "गूगल" to "google", "मैप्स" to "maps", "जीमेल" to "gmail",
        "इंस्टाग्राम" to "instagram", "फोन" to "phone", "क्रोम" to "chrome",
        "कैलकुलेटर" to "calculator", "घड़ी" to "clock", "म्यूजिक" to "music"
    )

    private val stop = setOf(
        "open", "kholo", "khol", "launch", "खोलो", "खोल", "चालू", "करो", "karo", "start", "app",
        "ऐप", "को", "ko", "please", "call", "कॉल", "फोन", "phone", "dial", "play", "chalao",
        "bajao", "चलाओ", "बजाओ", "search", "google", "dhundo", "ढूंढो", "सर्च", "navigate",
        "to", "directions", "send", "bhejo", "भेजो", "whatsapp", "message", "text", "मैसेज",
        "व्हाट्सएप", "on", "youtube", "me", "में", "par", "पर", "ka", "का", "ki", "की"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        // Let Jarvis appear over the lock screen (it does NOT bypass the lock)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else @Suppress("DEPRECATION") window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        buildUi()
        window.decorView.post { checkAuto(intent) }
        requestPermissions(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.ANSWER_PHONE_CALLS,
                "android.permission.POST_NOTIFICATIONS"
            ), 1
        )
        append("Jarvis", "Namaste! Mic dabaiye aur kuch bhi boliye: app kholna, call, alarm, message likhna, sawaal poochna. Pehle 🔑 AI key daal dijiye.")
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); setIntent(i); checkAuto(i) }

    private fun checkAuto(i: Intent?) {
        if (i?.getBooleanExtra("auto", false) == true) { auto = true; i.removeExtra("auto"); toggleListening() }
    }

    private fun bubble(on: Boolean) {
        if (on) {
            if (!Settings.canDrawOverlays(this)) {
                say("Pehle 'Display over other apps' ki permission dijiye, phir dobara Bubble ON dabaiye.")
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return
            }
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                say("Pehle microphone ki permission dijiye."); requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
            }
            startForegroundService(Intent(this, JarvisService::class.java))
            val hasKey = !(getSharedPreferences("jarvis", MODE_PRIVATE).getString("pkey", "")).isNullOrBlank()
            say(if (hasKey) "Jarvis chalu. Ab home screen par jaakar sirf 'Jarvis' boliye." else "Bubble chalu. 'Jarvis' bolke jagane ke liye 🔑 AI key mein Picovoice key bhi daaliye.")
        } else {
            stopService(Intent(this, JarvisService::class.java))
            say("Bubble band kar diya.")
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val cyan = Color.parseColor("#5FE3FF")
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#04101A"))
            setPadding(dp(16), dp(40), dp(16), dp(16))
        }
        val title = TextView(this).apply {
            text = "J A R V I S"; setTextColor(cyan); textSize = 18f; gravity = Gravity.CENTER
        }
        log = TextView(this).apply {
            setTextColor(Color.parseColor("#D6F4FF")); textSize = 16f
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }
        scroll = ScrollView(this).apply { addView(log) }
        input = EditText(this).apply {
            hint = "Ya yahan type karein…"; setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#6F9BB0")); imeOptions = EditorInfo.IME_ACTION_SEND
            setSingleLine(true)
            setOnEditorActionListener { _, _, _ -> sendTyped(); true }
        }
        val send = Button(this).apply { text = "Send"; setOnClickListener { sendTyped() } }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(send)
        }
        mic = Button(this).apply {
            text = "🎤  Bolo"; textSize = 20f
            setOnClickListener { toggleListening() }
        }
        root.addView(title)
        root.addView(Button(this).apply { text = "🔑 AI key"; setOnClickListener { showKeyDialog() } })
        root.addView(Button(this).apply {
            text = "⌨️ Typing ON (Accessibility)"
            setOnClickListener {
                say("Accessibility mein Jarvis dhundkar chalu kijiye. Agar band dikhe to App info, teen dots, Allow restricted settings.")
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(Button(context).apply { text = "🫧 Jarvis ON"; setOnClickListener { bubble(true) } }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(Button(context).apply { text = "Jarvis OFF"; setOnClickListener { bubble(false) } }, LinearLayout.LayoutParams(0, -2, 1f))
        })
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(row)
        root.addView(mic, LinearLayout.LayoutParams(-1, dp(64)).apply { topMargin = dp(8) })
        setContentView(root)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { if (auto) { auto = false; JarvisService.instance?.resumeListening(); pendingType?.let { t -> pendingType = null; Handler(Looper.getMainLooper()).postDelayed({ JarvisAccess.instance?.typeText(t) }, 1000) }; runOnUiThread { finish() } } }
                override fun onError(id: String?) { if (auto) { auto = false; JarvisService.instance?.resumeListening(); pendingType?.let { t -> pendingType = null; Handler(Looper.getMainLooper()).postDelayed({ JarvisAccess.instance?.typeText(t) }, 1000) }; runOnUiThread { finish() } } }
            })
            val r = tts.setLanguage(Locale("hi", "IN"))
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(Locale.getDefault())
        }
    }

    private fun append(who: String, text: String) {
        log.append("$who: $text\n\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun say(text: String) {
        append("Jarvis", text)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun sendTyped() {
        val t = input.text.toString()
        input.setText("")
        if (t.isNotBlank()) handle(t)
    }

    private fun toggleListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            say("Pehle microphone ki permission dijiye."); requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { say("Is phone mein voice recognition nahi mila."); return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { mic.text = "👂  Sun raha hoon…" }
                override fun onResults(r: Bundle?) {
                    mic.text = "🎤  Bolo"
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { handle(it) }
                }
                override fun onError(e: Int) { mic.text = "🎤  Bolo"; say("Sunai nahi diya, dobara boliye.") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")   // Hindi + English words
        }
        recognizer?.startListening(i)
    }

    private fun handle(text: String) {
        append("Aap", text)
        val local = process(text.lowercase(Locale.ROOT).trim())
        if (local != null) say(local) else askAi(text)
    }

    private fun strip(s: String): String =
        s.split(" ", ",").filter { it.isNotBlank() && it !in stop }.joinToString(" ").trim()

    private fun go(i: Intent): Boolean = try { startActivity(i); true } catch (e: ActivityNotFoundException) { false }

    private fun process(s: String): String? {
        fun has(vararg w: String) = w.any { s.contains(it) }
        if (has("type ", "likho", "likh do", "likh ", "लिखो", "लिख दो", "write")) return null  // writing -> AI

        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val callWord = has("call", "कॉल", "फोन")
        if (has("unlock", "अनलॉक", "lock khol", "phone ka lock")) {
            if (!km.isKeyguardLocked) return "Phone pehle se unlock hai."
            auto = false; pendingAfterUnlock = null; requestUnlock()
            return "Unlock ke liye apna PIN, pattern ya fingerprint lagaiye."
        }
        if (callWord && has("uthao", "utha", "pick", "answer", "receive", "accept", "उठाओ", "रिसीव")) return answerCall()
        if (callWord && has("kaato", "cut", "reject", "decline", "hang up", "end call", "काटो", "काट")) return endCall()
        // Locked phone: private actions need the owner to unlock first
        if (km.isKeyguardLocked && km.isKeyguardSecure && has(
                "call", "कॉल", "फोन करो", "dial", "sms", "एसएमएस", "whatsapp", "व्हाट्सएप", "message", "मैसेज",
                "email", "ईमेल", "open", "kholo", "khol", "launch", "खोलो", "खोल", "चालू करो",
                "play", "chalao", "bajao", "चलाओ", "बजाओ", "navigate", "directions", "raasta", "रास्ता",
                "search", "dhundo", "ढूंढो", "सर्च", "wifi", "वाईफाई", "bluetooth", "ब्लूटूथ")) {
            auto = false; pendingAfterUnlock = s; requestUnlock()
            return "Phone locked hai. Apne PIN, pattern ya fingerprint se unlock kijiye, phir main kaam kar dunga."
        }

        if (has("torch", "flashlight", "टॉर्च", "टोर्च", "फ्लैशलाइट")) {
            val on = !has("off", "band", "बंद", "बन्द")
            return try {
                val cm = getSystemService(CAMERA_SERVICE) as CameraManager
                cm.setTorchMode(cm.cameraIdList[0], on)
                if (on) "Torch chalu kar di." else "Torch band kar di."
            } catch (e: Exception) { "Torch nahi chal paayi." }
        }

        if (has("timer", "टाइमर")) {
            val m = Regex("(\\d+)\\s*(second|sec|सेकंड|सेकेंड|minute|min|मिनट|hour|घंटे|घंटा)").find(s)
                ?: return "Kitne der ka timer? Jaise: 5 minute ka timer."
            val n = m.groupValues[1].toInt(); val u = m.groupValues[2]
            val sec = when {
                u.startsWith("h") || u.startsWith("घं") -> n * 3600
                u.startsWith("m") || u.startsWith("मि") -> n * 60
                else -> n
            }
            go(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, sec).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return "Timer laga diya: ${m.groupValues[1]} ${m.groupValues[2]}."
        }

        if (has("alarm", "अलार्म")) {
            val m = Regex("(\\d{1,2})(?:[:.](\\d{2}))?").find(s) ?: return "Kis time ka alarm? Jaise: alarm 6:30 am."
            var h = m.groupValues[1].toInt()
            val min = m.groupValues[2].ifEmpty { "0" }.toInt()
            if (has("pm", "शाम", "रात", "दोपहर") && h < 12) h += 12
            if (has("am") && h == 12) h = 0
            go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, min).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return "Alarm set: %02d:%02d.".format(h, min)
        }

        if (has("call", "कॉल", "फोन करो", "phone karo", "dial")) {
            val target = strip(s)
            val digits = target.replace(" ", "")
            val num = if (digits.matches(Regex("[+\\d]{5,}"))) digits else findNumber(target)
                ?: return "Contact nahi mila: $target"
            val granted = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
            val uri = Uri.parse("tel:" + Uri.encode(num))
            go(Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri))
            return "Call lag raha hai: $target"
        }

        if (has("wifi", "वाईफाई", "वाई-फाई")) { go(Intent(Settings.ACTION_WIFI_SETTINGS)); return "Wi-Fi settings khol di." }
        if (has("bluetooth", "ब्लूटूथ")) { go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); return "Bluetooth settings khol di." }

        if (has("open", "kholo", "khol", "launch", "खोलो", "खोल", "चालू करो")) {
            var name = strip(s)
            aliases.forEach { (k, v) -> if (name.contains(k)) name = v }
            return openApp(name)
        }

        if (has("play", "chalao", "bajao", "चलाओ", "बजाओ")) {
            val q = strip(s)
            go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
            return "YouTube par chala raha hoon: $q"
        }

        if (has("navigate", "directions", "raasta", "रास्ता", "le chalo", "ले चलो")) {
            val q = strip(s).replace("raasta", "").replace("रास्ता", "").trim()
            go(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(q))))
            return "Maps mein raasta dikha raha hoon: $q"
        }

        if (has("whatsapp", "व्हाट्सएप", "message", "मैसेज")) {
            val q = strip(s)
            go(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/?text=" + Uri.encode(q))))
            return "WhatsApp mein contact chuniye, message ready hai."
        }

        if (has("search", "dhundo", "ढूंढो", "सर्च", "google")) {
            val q = strip(s)
            go(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
            return "Search kar raha hoon: $q"
        }

        if (has("sms", "एसएमएस")) {
            val t = s.split(" ").filter { it.isNotBlank() && it !in setOf("sms", "एसएमएस", "to", "bhejo") }
            val target = t.firstOrNull() ?: return "Kisko SMS bhejun?"
            val num = if (target.matches(Regex("[+\\d]{5,}"))) target else findNumber(target) ?: return "Contact nahi mila: $target"
            go(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(num))).putExtra("sms_body", t.drop(1).joinToString(" ")))
            return "SMS ready hai, bhejne ke liye Send dabaiye."
        }
        if (has("email", "ईमेल")) {
            val body = s.replace("email", "").replace("ईमेल", "").trim()
            go(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).putExtra(Intent.EXTRA_TEXT, body))
            return "Email ready hai."
        }
        if (has("volume", "आवाज़", "awaaz")) {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val up = !has("down", "kam", "कम", "low")
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            return if (up) "Volume badha diya." else "Volume kam kar diya."
        }
        if (has("battery", "बैटरी")) {
            val b = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            return "Battery " + b.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) + " percent hai."
        }

        if (has("time", "samay", "टाइम", "समय", "कितने बजे"))
            return "Abhi " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()) + " baje hain."
        if (has("date", "तारीख", "aaj", "आज"))
            return "Aaj " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()) + " hai."
        if (has("hello", "hi ", "namaste", "नमस्ते")) return "Namaste! Boliye, kya kaam hai?"

        return null  // not a built-in command -> ask the AI
    }

    private fun showKeyDialog() {
        val p = getSharedPreferences("jarvis", MODE_PRIVATE)
        val k1 = EditText(this).apply { hint = "Anthropic key (sk-ant-...)"; setText(p.getString("key", "")); setSingleLine(true) }
        val k2 = EditText(this).apply { hint = "Picovoice AccessKey (Jarvis naam ke liye)"; setText(p.getString("pkey", "")); setSingleLine(true) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0); addView(k1); addView(k2) }
        AlertDialog.Builder(this)
            .setTitle("Keys")
            .setMessage("Dono keys sirf is phone mein save hoti hain.")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                p.edit().putString("key", k1.text.toString().trim()).putString("pkey", k2.text.toString().trim()).apply()
                say("Keys save ho gayi. Jarvis OFF karke phir Jarvis ON dabaiye.")
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun askAi(q: String) {
        val key = getSharedPreferences("jarvis", MODE_PRIVATE).getString("key", "") ?: ""
        if (key.isBlank()) { say("Iske liye AI chahiye. Upar 🔑 AI key button se Anthropic API key daaliye."); return }
        history.put(JSONObject().put("role", "user").put("content", q))
        while (history.length() > 12) history.remove(0)
        while (history.length() > 0 && history.getJSONObject(0).getString("role") != "user") history.remove(0)
        thread {
            val result = try { Result.success(callClaude(key)) } catch (e: Exception) { Result.failure<String>(e) }
            runOnUiThread {
                result.onSuccess { r ->
                    history.put(JSONObject().put("role", "assistant").put("content", r))
                    if (r.trim().startsWith("CMD:")) {
                        say(process(r.trim().removePrefix("CMD:").trim().lowercase(Locale.ROOT)) ?: "Ye kaam mujhse nahi ho paaya.")
                    } else if (r.trim().startsWith("TYPE:")) typeOut(r.trim().removePrefix("TYPE:").trim()) else say(r.trim())
                }.onFailure { e ->
                    history.remove(history.length() - 1)
                    say("AI se jawab nahi mila: ${e.message}")
                }
            }
        }
    }

    private fun callClaude(key: String): String {
        val body = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 400)
            .put("system", sys).put("messages", history)
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 40000; c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        if (code == 401) throw Exception("API key galat hai")
        val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code !in 200..299) throw Exception("API error $code")
        val arr = JSONObject(txt).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until arr.length()) arr.getJSONObject(i).optString("text").let { sb.append(it) }
        return sb.toString()
    }

    private fun answerCall(): String {
        if (checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ANSWER_PHONE_CALLS), 1)
            return "Pehle call uthane ki permission dijiye, phir dobara boliye."
        }
        return try {
            (getSystemService(Context.TELECOM_SERVICE) as TelecomManager).acceptRingingCall()
            "Call utha liya."
        } catch (e: Exception) { "Call nahi utha paaya." }
    }

    private fun endCall(): String {
        if (Build.VERSION.SDK_INT < 28) return "Is Android version par call kaatna mumkin nahi."
        if (checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ANSWER_PHONE_CALLS), 1)
            return "Pehle call ki permission dijiye, phir dobara boliye."
        }
        return try {
            val ok = (getSystemService(Context.TELECOM_SERVICE) as TelecomManager).endCall()
            if (ok) "Call kaat diya." else "Koi chalti call nahi mili."
        } catch (e: Exception) { "Call nahi kaat paaya." }
    }

    /** Shows the system unlock prompt. The owner must enter PIN/pattern/fingerprint; Jarvis never sees it. */
    private fun requestUnlock() {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() {
                val c = pendingAfterUnlock; pendingAfterUnlock = null
                if (c != null) say(process(c) ?: "Kaam ho gaya.")
                Handler(Looper.getMainLooper()).postDelayed({
                    JarvisService.instance?.resumeListening(); finish()
                }, if (c != null) 3500L else 300L)
            }
            override fun onDismissCancelled() { JarvisService.instance?.resumeListening() }
            override fun onDismissError() { say("Unlock nahi ho paaya.") }
        })
    }

    private fun typeOut(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("jarvis", text))
        append("Jarvis", text)
        if (auto && JarvisAccess.instance != null) {
            pendingType = text
            say("Likh raha hoon.")
        } else if (JarvisAccess.instance == null) {
            say("Likh diya aur copy kar liya, kahin bhi paste kar dijiye. Seedha type karne ke liye Typing ON dabaiye.")
        } else {
            say("Likh diya aur copy kar liya, paste kar dijiye.")
        }
    }

    private fun openApp(name: String): String {
        if (name.isBlank()) return "Kaun sa app kholun?"
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == name }
            ?: apps.firstOrNull {
                val l = it.loadLabel(pm).toString().lowercase()
                l.contains(name) || (l.length > 2 && name.contains(l))
            } ?: return "\"$name\" naam ka app nahi mila."
        val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return "App khul nahi paaya."
        startActivity(launch)
        return "${hit.loadLabel(pm)} khol raha hoon."
    }

    private fun findNumber(name: String): String? {
        if (name.isBlank() || checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"), null
        )?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    override fun onDestroy() {
        recognizer?.destroy(); tts.shutdown(); super.onDestroy()
    }
}
