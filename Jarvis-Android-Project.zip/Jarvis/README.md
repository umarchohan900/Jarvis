# Jarvis (Android)

1. Install Android Studio (Koala or newer).
2. File > Open > select this "Jarvis" folder. Let Gradle sync finish.
3. Phone: Settings > About phone > tap Build number 7 times > enable USB debugging.
4. Connect phone with USB, press the green Run button.
5. Allow Microphone, Contacts and Phone permissions on first launch.

To get an APK file: Build > Build APK(s).

Voice recognition and Hindi speech need the Google app / Google speech services on the phone.
